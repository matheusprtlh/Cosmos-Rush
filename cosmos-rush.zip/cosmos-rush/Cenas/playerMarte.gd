extends CharacterBody2D

const SPEED = 100.0 # Velocidade de movimento lateral
const JUMP_FORCE = -200.0 # Força do pulo (negativo vai para cima)
var gravity = 300.0 # Gravidade

@onready var anim = $AnimatedSprite2D

func _physics_process(delta):
	# Gravidade
	if not is_on_floor():
		velocity.y += gravity * delta

	# Pulo
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_FORCE

	# Movimentação lateral
	var direction = Input.get_axis("ui_left", "ui_right")

	if direction:
		velocity.x = direction * SPEED
		anim.flip_h = direction < 0
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()

	# Escolher animação
	var anim_name = "idle"

	if not is_on_floor():
		if velocity.y < 0.0:
			anim_name = "jump"
		else:
			anim_name = "fall"
	else:
		if direction != 0.0:
			anim_name = "run"
		else:
			anim_name = "idle"

	# Só troca se a animação for diferente, para não reiniciar à toa
	if anim.animation != anim_name:
		anim.play(anim_name)
