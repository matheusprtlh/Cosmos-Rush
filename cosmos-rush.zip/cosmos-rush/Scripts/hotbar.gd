extends Control

# Mapeia cada slot para um item do inventário
var itens_slots: Array[String] = [
	"pepita_ouro",
	"pepita_diamante",
	"pepita_rubi",
	"pepita_esmeralda",
	"nucleo",
	"",
	"",
	""
]

@onready var slots_container: HBoxContainer = $SlotsContainer

func _process(_delta):
	atualizar()

func atualizar():
	for i in slots_container.get_child_count():
		var slot = slots_container.get_child(i)
		var icone = slot.get_node("IconeItem")
		var label = slot.get_node("QtdLabel")

		if i >= itens_slots.size() or itens_slots[i] == "":
			icone.texture = null
			label.text = ""
			slot.modulate = Color(1, 1, 1, 0.3)
			continue

		var item_nome = itens_slots[i]
		var qtd = InventoryManager.get_quantidade(item_nome)

		var caminho = "res://Imagens/" + item_nome + ".png"
		if ResourceLoader.exists(caminho):
			icone.texture = load(caminho)

		if qtd > 0:
			label.text = str(qtd)
			slot.modulate = Color.WHITE
		else:
			label.text = ""
			slot.modulate = Color(1, 1, 1, 0.3)
