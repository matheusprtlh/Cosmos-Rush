extends CharacterBody2D

# === CONFIGURAÇÕES DE MOVIMENTO ===
const SPEED = 150.0
const JUMP_FORCE = -290.0
var gravity = 800.0 

# === SISTEMA DE OXIGÊNIO E PROGRESSO ===
var oxigenio_maximo: int = 100
var oxigenio_atual: int = 100
var perda_por_segundo: float = 1.0
var recuperacao_capsula: int = 20
var tem_nucleo: bool = false # Variável para saber se pegou o núcleo

# === REFERÊNCIAS DOS NÓS ===
@onready var anim = $AnimatedSprite2D
@onready var barra_oxigenio: ProgressBar = $CanvasLayer/ProgressBar
@onready var label_oxigenio: Label = $CanvasLayer/LabelOxigenio
@onready var timer_oxigenio: Timer = $Timer

func _ready():
	# Configuração do Timer (ajustei para 1.0s conforme documentação, mas mantive seu 0.3 se preferir)
	timer_oxigenio.wait_time = 0.3
	 
	timer_oxigenio.autostart = true
	timer_oxigenio.one_shot = false
	timer_oxigenio.connect("timeout", Callable(self, "_on_timer_timeout"))
	timer_oxigenio.start()
	atualizar_ui_oxigenio()

func _physics_process(delta):
	# Gravidade
	if not is_on_floor():
		velocity.y += gravity * delta

	# Pulo
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_FORCE

	# Movimentação lateral
	var direction = Input.get_axis("ui_left", "ui_right")
	if direction:
		velocity.x = direction * SPEED
		anim.flip_h = direction < 0
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()

	# Animações
	var anim_name = "idle"
	if not is_on_floor():
		anim_name = "jump" if velocity.y < 0.0 else "fall"
	else:
		anim_name = "run" if direction != 0.0 else "idle"
	
	if anim.animation != anim_name:
		anim.play(anim_name)
	
	# Morte por queda
	if position.y > 1000:
		game_over()

# === SISTEMA DE OXIGÊNIO ===
func _on_timer_timeout():
	oxigenio_atual -= perda_por_segundo
	atualizar_ui_oxigenio()
	if oxigenio_atual <= 0:
		game_over()

func atualizar_ui_oxigenio():
	if barra_oxigenio and label_oxigenio:
		barra_oxigenio.value = oxigenio_atual
		barra_oxigenio.max_value = oxigenio_maximo
		label_oxigenio.text = str(int(oxigenio_atual)) + "/100"
		
		if oxigenio_atual <= 20:
			barra_oxigenio.modulate = Color.RED
		elif oxigenio_atual <= 50:
			barra_oxigenio.modulate = Color.YELLOW
		else:
			barra_oxigenio.modulate = Color.GREEN

func recuperar_oxigenio(quantidade: int = recuperacao_capsula):
	oxigenio_atual += quantidade
	if oxigenio_atual > oxigenio_maximo:
		oxigenio_atual = oxigenio_maximo
	atualizar_ui_oxigenio()
	print("+ Oxigênio!")

# === COLISÃO COM CÁPSULAS ===
# Esta função deve ser conectada ao sinal 'body_entered' da sua Area2D da Cápsula
# Ou você pode usar a lógica dentro do script da própria cápsula como vimos antes.
func _on_capsula_body_entered(body):
	if body == self:
		recuperar_oxigenio()
		body.queue_free()

func game_over():
	timer_oxigenio.stop()
	print("GAME OVER - Sem oxigênio ou caiu no vazio!")
	get_tree().change_scene_to_file("res://game_over.tscn")
