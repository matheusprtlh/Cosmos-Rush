extends Node2D

# Caminhos dos seus 3 players
const PLAYERS = {
	"terra": "res://Cenas/player.tscn",
	"marte": "res://Cenas/playerMarte.gd",
	"lua": "res://Cenas/playerLua.gd"
}

func _ready():
	# Inicia com o jogador da Terra por padrão
	trocar_planeta("terra")

func trocar_planeta(planeta: String):
	# Remove o jogador atual se existir
	if $FaseAtual.get_child_count() > 0:
		$FaseAtual.get_child(0).queue_free()
	
	# Carrega e adiciona o novo jogador
	var caminho = PLAYERS.get(planeta)
	if caminho:
		var novo_player = load(caminho).instantiate()
		$FaseAtual.add_child(novo_player)
		print("✅ Trocado para: ", planeta)
	else:
		push_error("❌ Planeta não encontrado: ", planeta)
