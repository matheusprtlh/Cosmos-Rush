extends CharacterBody2D
const SPEED = 250.0
const JUMP_FORCE = -300.0
var gravity = 780.0

@onready var anim = $AnimatedSprite2D

func _physics_process(delta):
	if not esta_no_chao():
		velocity.y += gravity * delta
	else:
		if anim.is_playing() and anim.animation == "jump":
			anim.play("idle")
	
	if Input.is_action_just_pressed("ui_accept") and esta_no_chao():
		velocity.y = JUMP_FORCE
		anim.play("jump")
	
	var direction = Input.get_axis("ui_left", "ui_right")
	
	if direction:
		velocity.x = direction * SPEED 
		anim.play("run") 
		anim.flip_h = (direction < 0)
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED) 
		if anim.animation != "jump":
			anim.play("idle") 
	
	move_and_slide()

func esta_no_chao() -> bool:
	return is_on_floor()
