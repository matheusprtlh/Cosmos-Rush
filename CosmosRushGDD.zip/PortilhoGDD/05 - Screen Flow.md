# 📱 Screen Flow — Fluxo de Telas
#GDD #CosmosRunner #screenflow

← [[04 - Mecânicas e Controles]]

## Diagrama de Telas

```
[Splash Screen]
     ↓
[Menu Principal]
  ├── Jogar → [Seleção de Planeta]
  ├── Créditos → [Tela de Créditos]
  └── Sair → Fecha o jogo

[Seleção de Planeta]
  └── Escolhe planeta → [Gameplay]

[Gameplay]
  ├── ESC → [Pausa]
  │         ├── Continuar → [Gameplay]
  │         └── Menu → [Menu Principal]
  ├── Morre → [Tela de Game Over]
  │           ├── Tentar Novamente → [Gameplay]
  │           └── Menu → [Menu Principal]
  └── Coleta Núcleo → [Tela de Fase Completa]
                      ├── Próximo Planeta → [Gameplay]
                      └── Mapa → [Seleção de Planeta]

[Tela Final — Todos os Núcleos]
  └── Menu → [Menu Principal]
```

## Descrição de Cada Tela

| Tela                  | O que aparece                                              |
|-----------------------|------------------------------------------------------------|
| Splash Screen         | Logo do jogo + nome "Cosmos Runner", sem botão, 3 segundos |
| Menu Principal        | Título + botões: Jogar, Créditos, Sair                     |
| Seleção de Planeta    | Mapa do sistema solar, planetas clicáveis/desbloqueáveis   |
| Gameplay              | Fase + HUD (barra de oxigênio + contador de núcleos)       |
| Pausa                 | Overlay escuro + botões Continuar e Menu                   |
| Game Over             | Ícone de capacete trincado + botões                        |
| Fase Completa         | Animação do Núcleo + botões                                |
| Tela Final            | Animação da nave voltando para a Terra                     |
| Créditos              | Nomes da equipe                                            |

---
← [[04 - Mecânicas e Controles]] | → [[06 - Fases e Planetas]]
