# 👾 Inimigos e Obstáculos
#GDD #CosmosRunner #inimigos

← [[06 - Fases e Planetas]]

## Filosofia
Sem inimigos que "atacam" ativamente. Os obstáculos são elementos do ambiente que refletem as características reais dos planetas.
> Isso mantém o jogo acessível para todas as idades e elimina a necessidade de IA de inimigo complexa.

---

## Obstáculos por Tipo

### 🌡️ Zonas de Temperatura
- **Onde:** Mercúrio, Vênus
- **Efeito:** Drenam a barra de oxigênio/vida ao ficar parado nelas
- **Visual:** Chão brilhando vermelho (calor) ou névoa amarela (tóxico)

### 💨 Correntes de Vento
- **Onde:** Júpiter, Netuno
- **Efeito:** Empurram o personagem horizontalmente
- **Visual:** Linhas de partículas indicando a direção

### 🧊 Plataformas Instáveis
- **Onde:** Saturno
- **Tipos:**
  - Plataforma de gelo: escorrega
  - Plataforma quebradiça: desaparece 2 segundos após o primeiro piso

### 🌑 Sombra e Visibilidade Zero
- **Onde:** Netuno, partes de Vênus
- **Efeito:** Tela escurece, jogador precisa memorizar o caminho
- **Visual:** Overlay de névoa/escuridão com gradiente

### ☄️ Meteoros
- **Onde:** Mercúrio, fase da Lua
- **Efeito:** Caem do topo da tela em posições previsíveis
- **Visual:** Rocha com rastro de fogo, animação simples

### 🌀 Zona de Gravidade Invertida
- **Onde:** Urano
- **Efeito:** O "chão" passa a ser o teto nessa região
- **Visual:** Seta visual indicando a direção da gravidade

---

## Tabela Resumo por Fase

| Fase      | Obstáculos Presentes                            |
|-----------|-------------------------------------------------|
| Mercúrio  | Plataformas quentes, meteoros                   |
| Vênus     | Névoa tóxica, visibilidade reduzida             |
| Marte     | Tempestade de areia (visibilidade), gravidade ↓ |
| Lua       | Gravidade muito baixa, meteoros                 |
| Júpiter   | Gravidade alta, vento horizontal                |
| Saturno   | Plataformas de gelo, plataformas quebradiças    |
| Urano     | Gravidade invertida                             |
| Netuno    | Vento aleatório, visibilidade zero              |

---
← [[06 - Fases e Planetas]] | → [[08 - Core Loop]]
