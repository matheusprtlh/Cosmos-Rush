# 🪐 Fases e Planetas
#GDD #CosmosRunner #level-design

← [[05 - Screen Flow]]

## Estrutura Geral
- 8 fases principais (1 por planeta)
- Ordem sugerida de dificuldade crescente
- Cada fase tem: ambiente único + mecânica especial + 1 Núcleo de Dados

---

## Fase 1 — Mercúrio
- **Dificuldade:** ⭐☆☆☆☆
- **Visual:** Rochas escuras, superfície cratericada, sem céu azul
- **Mecânica especial:** Plataformas que aquecem — ficar parado causa dano
- **Ensina:** Mercúrio não tem atmosfera, temperatura extrema
- **Núcleo:** Dentro de uma cratera no fim da fase

## Fase 2 — Vênus
- **Dificuldade:** ⭐⭐☆☆☆
- **Visual:** Laranja/amarelo, nuvens densas de fundo, visibilidade reduzida
- **Mecânica especial:** Névoa tóxica em partes da fase — drena oxigênio mais rápido
- **Ensina:** Vênus tem atmosfera densa e tóxica
- **Núcleo:** No topo de uma formação rochosa

## Fase 3 — Marte
- **Dificuldade:** ⭐⭐☆☆☆
- **Visual:** Vermelho, deserto, canyon profundo
- **Mecânica especial:** Gravidade reduzida (pulo maior), tempestades de areia que reduzem visibilidade
- **Ensina:** Marte tem gravidade menor e tempestades de areia
- **Núcleo:** Dentro de uma caverna

## Fase 4 — Lua (bônus entre Marte e Júpiter)
- **Dificuldade:** ⭐⭐⭐☆☆
- **Visual:** Cinza, crateras, estrelas visíveis no fundo
- **Mecânica especial:** Gravidade muito baixa, pulos flutuantes longos
- **Ensina:** A Lua tem gravidade muito menor que a Terra
- **Núcleo:** Flutuando em plataforma central

## Fase 5 — Júpiter
- **Dificuldade:** ⭐⭐⭐☆☆
- **Visual:** Listras de nuvens laranja e marrom, sem superfície sólida — tudo plataformas de nuvem
- **Mecânica especial:** Gravidade alta (pulo menor), ventos fortes horizontais
- **Ensina:** Júpiter é gigante, tem gravidade enorme e é gasoso
- **Núcleo:** Na Grande Mancha Vermelha (decoração visual)

## Fase 6 — Saturno
- **Dificuldade:** ⭐⭐⭐⭐☆
- **Visual:** Amarelo pálido, anéis visíveis no fundo, plataformas de gelo
- **Mecânica especial:** Plataformas de gelo escorregam e quebram após 2 segundos
- **Ensina:** Saturno tem anéis de gelo e rocha
- **Núcleo:** Na última plataforma do anel

## Fase 7 — Urano
- **Dificuldade:** ⭐⭐⭐⭐☆
- **Visual:** Azul-esverdeado, inclinado (a câmera fica levemente rotacionada)
- **Mecânica especial:** Fase "invertida" — gravidade muda de direção em certas zonas
- **Ensina:** Urano é inclinado 98°, "rola" em vez de girar
- **Núcleo:** Em zona de gravidade invertida

## Fase 8 — Netuno
- **Dificuldade:** ⭐⭐⭐⭐⭐
- **Visual:** Azul escuro, visibilidade quase zero, partículas voando
- **Mecânica especial:** Ventos fortíssimos mudam de direção aleatoriamente
- **Ensina:** Netuno tem os ventos mais rápidos do Sistema Solar
- **Núcleo:** No centro de um olho da tempestade

---
← [[05 - Screen Flow]] | → [[07 - Inimigos e Obstáculos]]
