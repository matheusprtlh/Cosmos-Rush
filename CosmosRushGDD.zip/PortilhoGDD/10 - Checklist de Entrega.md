# ✅ Checklist de Entrega — Módulo 1
#GDD #CosmosRunner #checklist

← [[09 - Assets List]]

## Requisitos Obrigatórios do Projeto

- [x] Definir o pilar pedagógico (matéria, público, objetivo de aprendizagem) → [[02 - Pilar Educativo]]
- [x] Escrever a Lore em 1 parágrafo → [[03 - Narrativa]]
- [x] Escrever o Plot em 1 parágrafo → [[03 - Narrativa]]
- [x] Mapear mecânicas e controles do personagem → [[04 - Mecânicas e Controles]]
- [x] Criar o Screen Flow de telas → [[05 - Screen Flow]]
- [x] Definir o level design (fases e planetas) → [[06 - Fases e Planetas]]
- [x] Listar os assets necessários → [[09 - Assets List]]

---

## Próximas Etapas (Módulo 2 — Prototipagem)

- [ ] Criar cena base no motor de jogo (Unity ou Godot)
- [ ] Implementar movimentação básica do astronauta
- [ ] Testar gravidade variável por planeta
- [ ] Criar 1 fase de teste (Marte recomendado — mecânica mais simples)
- [ ] Testar loop de coleta do Núcleo e abertura do portal

---

## Formato de Entrega do GDD
- [x] Documento organizado (Obsidian / Notion / PDF)
- [ ] Exportar para PDF antes de entregar
- [x] Sem uso de Unity/Godot nessa etapa

---

## Observação
> O GDD é um documento vivo. Se uma mecânica mudar durante o desenvolvimento, atualize aqui primeiro.

---
← [[09 - Assets List]] | [[01 - Visão Geral]] (voltar ao início)
