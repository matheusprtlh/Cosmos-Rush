# ⚙️ Mecânicas e Controles
#GDD #CosmosRunner #mecanicas

← [[03 - Narrativa]]

## Mapeamento de Teclas
| Tecla  | Ação                        |
| ------ | --------------------------- |
| ← →    | Mover para esquerda/direita |
| Espaço | Pular                       |
| ↑ ou W | Pular (alternativo)         |
| E      | Interagir / Coletar         |
| ESC    | Pausar o jogo               |

---

## Mecânicas Principais

### 🏃 Movimentação Base
- Correr e pular são o núcleo do jogo
- Cada planeta **modifica** como esses movimentos funcionam

### 🌍 Gravidade Variável por Planeta
A principal mecânica indireta de ensino:
- **Marte:** pulo 40% mais alto (gravidade menor)
- **Júpiter:** pulo 60% menor, movimento lento (gravidade maior)
- **Lua:** pulo muito alto, flutua por mais tempo

### 💨 Vento e Correntes
- Em Netuno e Júpiter: ventos empurram o personagem horizontalmente
- O jogador precisa se posicionar antecipando o empurrão

### 🧊 Plataformas Especiais
- **Saturno:** plataformas de gelo dos anéis — escorregam e quebram
- **Mercúrio:** plataformas de rocha que esquentam e causam dano se o jogador ficar parado

### ⚡ Barra de Oxigênio
- Cada planeta tem um tempo limite de oxigênio diferente
- Coletar cápsulas espalhadas pelas fases reabastece o oxigênio
- Acaba o oxigênio → Game Over (sem morte violenta, apenas escurecimento da tela)

### 🔵 Núcleo de Dados (Objetivo da Fase)
- 1 Núcleo escondido por planeta
- Quando coletado: animação simples + portal de saída abre
- Sem diálogo, sem texto — apenas visual

---

## Mecânicas Secundárias (Mistura)
- [ ] Plataformas móveis
- [ ] Plataformas que quebram ao pisar
- [ ] Correntes de vento direcional
- [ ] Zonas de calor/frio que afetam a velocidade

---
← [[03 - Narrativa]] | → [[05 - Screen Flow]]
