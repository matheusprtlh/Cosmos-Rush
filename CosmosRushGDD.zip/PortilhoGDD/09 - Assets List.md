# 🎨 Assets List
#GDD #CosmosRunner #assets

← [[08 - Core Loop]]

## Sprites (Personagem)

| Asset                  | Descrição                              | Status     |
|------------------------|----------------------------------------|------------|
| ORBIT_idle             | Astronauta parado (1-2 frames)         | - [ ] Fazer |
| ORBIT_run              | Astronauta correndo (4-6 frames)       | - [ ] Fazer |
| ORBIT_jump             | Astronauta no ar (1 frame)             | - [ ] Fazer |
| ORBIT_fall             | Astronauta caindo (1 frame)            | - [ ] Fazer |
| ORBIT_interact         | Pegando o Núcleo (2 frames)            | - [ ] Fazer |

---

## Sprites (Objetos)

| Asset                  | Descrição                              | Status     |
|------------------------|----------------------------------------|------------|
| nucleo_dados           | Ícone do Núcleo (brilhante, azul)      | - [ ] Fazer |
| capsula_oxigenio       | Cápsula para recarregar oxigênio       | - [ ] Fazer |
| portal_saida           | Portal que abre ao coletar o Núcleo    | - [ ] Fazer |
| meteoro                | Rocha com rastro de fogo               | - [ ] Fazer |

---

## Tilesets (Plataformas por Planeta)

| Planeta   | Tipo de Tile          | Status     |
|-----------|-----------------------|------------|
| Mercúrio  | Rocha escura/crateras | - [ ] Fazer |
| Vênus     | Rocha laranja/amarela | - [ ] Fazer |
| Marte     | Areia vermelha        | - [ ] Fazer |
| Lua       | Rocha cinza           | - [ ] Fazer |
| Júpiter   | Nuvem laranja/marrom  | - [ ] Fazer |
| Saturno   | Gelo translúcido      | - [ ] Fazer |
| Urano     | Cristal azul-verde    | - [ ] Fazer |
| Netuno    | Pedra azul escura     | - [ ] Fazer |

---

## Fundos (Backgrounds)

| Fase      | Descrição do Background              | Status     |
|-----------|--------------------------------------|------------|
| Menu      | Espaço com estrelas, planeta ao fundo | - [ ] Fazer |
| Mercúrio  | Céu preto, sol enorme                | - [ ] Fazer |
| Vênus     | Nuvens laranjas densas               | - [ ] Fazer |
| Marte     | Céu avermelhado, canyon              | - [ ] Fazer |
| Lua       | Espaço preto, Terra ao fundo         | - [ ] Fazer |
| Júpiter   | Listras de nuvem, Grande Mancha      | - [ ] Fazer |
| Saturno   | Anéis visíveis, espaço roxo          | - [ ] Fazer |
| Urano     | Azul-esverdeado, inclinado           | - [ ] Fazer |
| Netuno    | Azul escuro, partículas voando       | - [ ] Fazer |

---

## Sons e Música

| Asset              | Descrição                             | Status     |
|--------------------|---------------------------------------|------------|
| sfx_pulo           | Som de pulo do astronauta             | - [ ] Fazer |
| sfx_coleta         | Som ao pegar cápsula de oxigênio      | - [ ] Fazer |
| sfx_nucleo         | Som ao coletar o Núcleo de Dados      | - [ ] Fazer |
| sfx_morte          | Som de Game Over (sutil)              | - [ ] Fazer |
| sfx_vento          | Loop de vento (Júpiter, Netuno)       | - [ ] Fazer |
| musica_menu        | Trilha ambiente do menu               | - [ ] Fazer |
| musica_mercurio    | Trilha de Mercúrio                    | - [ ] Fazer |
| musica_marte       | Trilha de Marte                       | - [ ] Fazer |
| musica_jupyter     | Trilha de Júpiter                     | - [ ] Fazer |
| musica_fim         | Trilha da tela final                  | - [ ] Fazer |

---

## HUD (Interface)

| Asset              | Descrição                             | Status     |
|--------------------|---------------------------------------|------------|
| barra_oxigenio     | Barra visual de oxigênio              | - [ ] Fazer |
| icone_nucleo       | Contador de núcleos coletados         | - [ ] Fazer |
| botao_pausar       | Ícone de pausa (canto da tela)        | - [ ] Fazer |

---
← [[08 - Core Loop]] | → [[10 - Checklist de Entrega]]
