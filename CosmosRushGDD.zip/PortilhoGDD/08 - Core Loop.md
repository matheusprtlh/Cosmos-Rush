# 🔁 Core Loop
#GDD #CosmosRunner #core-loop

← [[07 - Inimigos e Obstáculos]]

## O Ciclo Principal

```
1. EXPLORAR
   O jogador navega pela fase, pulando entre plataformas
         ↓
2. REAGIR
   Encontra obstáculo ambiental (vento, calor, plataforma quebradiça)
         ↓
3. ADAPTAR
   Muda estratégia de movimento para sobreviver
   (ex: aprender a pular com gravidade diferente)
         ↓
4. COLETAR
   Encontra e pega o Núcleo de Dados
         ↓
5. RECOMPENSA
   Animação + portal abre + avança para o próximo planeta
         ↓
      repete
```

---

## Por que esse loop funciona?
- **Explorar** → mantém curiosidade
- **Reagir** → cria desafio sem precisar de texto
- **Adaptar** → aprendizado real acontece aqui (o jogador descobre as leis do planeta)
- **Coletar** → objetivo claro e simples
- **Recompensa** → sensação de progresso

## Loop Secundário (dentro da fase)
```
Vê obstáculo → tenta passar → falha → tenta de novo → consegue → avança
```
Esse micro-loop é o que mantém o jogador engajado momento a momento.

## Game Over Loop
```
Oxigênio acaba ou cai do cenário → tela escurece → botão "Tentar Novamente" → recomeça a fase
```
Sem punição severa — o jogador sempre pode tentar de novo imediatamente.

---
← [[07 - Inimigos e Obstáculos]] | → [[09 - Assets List]]
