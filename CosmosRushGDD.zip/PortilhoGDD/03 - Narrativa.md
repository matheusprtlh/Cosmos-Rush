# 📖 Narrativa
#GDD #CosmosRunner #narrativa

← [[02 - Pilar Educativo]]

## Lore (Contexto do Mundo)
No ano 2157, a humanidade perdeu contato com a estação espacial central após uma tempestade de partículas solares. Fragmentos do sistema de navegação da estação — chamados **Núcleos de Dados** — foram espalhados pelos planetas do Sistema Solar durante o caos. Sem esses núcleos, a humanidade não consegue mais se orientar no espaço.

*O jogador nunca lê isso no jogo — é o pano de fundo que justifica a arte e os cenários.*

---

## Plot (Missão Ativa do Jogador)
O astronauta **ORBIT** acorda sozinho em sua nave à deriva próxima a Mercúrio. Seu objetivo é simples: visitar cada planeta do Sistema Solar, sobreviver ao ambiente hostil e recuperar o **Núcleo de Dados** escondido em cada mundo. A cada planeta conquistado, ele se aproxima de voltar para casa.

**Início:** Nave caindo em Mercúrio
**Meio:** Explorar 8 planetas, cada um mais desafiador
**Fim:** Recuperar todos os Núcleos → chegar de volta à Terra

---

## Personagem Principal
**Nome:** ORBIT
**Visual:** Astronauta com traje branco, visor reflexivo (sem rosto visível — sem necessidade de expressões)
**Habilidades:** Pular, correr, interagir com objetos

---
← [[02 - Pilar Educativo]] | → [[04 - Mecânicas e Controles]]
