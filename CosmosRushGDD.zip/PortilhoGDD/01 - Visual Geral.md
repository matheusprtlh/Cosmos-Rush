# 🚀 Cosmos Runner — Visão Geral
#GDD #CosmosRunner #visao-geral

## Elevator Pitch
Um jogo de plataforma 2D onde um astronauta explora os planetas do Sistema Solar.
O jogador aprende as características de cada planeta sem perceber, apenas sobrevivendo aos desafios ambientais únicos de cada mundo.

## Público
- **Idade:** Todas as idades
- **Plataforma:** PC — Teclado

## Gênero
Plataforma 2D com elementos de exploração e puzzle ambiental

## Diferencial Pedagógico
A matéria (Ciências – Sistema Solar) é aprendida de forma **indireta**: o jogador enfrenta as propriedades reais de cada planeta como mecânica de jogo, sem provas ou perguntas explícitas.

---

## 🔗 Navegação do GDD
- [[02 - Pilar Educativo]]
- [[03 - Narrativa]]
- [[04 - Mecânicas e Controles]]
- [[05 - Screen Flow]]
- [[06 - Fases e Planetas]]
- [[07 - Inimigos e Obstáculos]]
- [[08 - Core Loop]]
- [[09 - Assets List]]
- [[10 - Checklist de Entrega]]
