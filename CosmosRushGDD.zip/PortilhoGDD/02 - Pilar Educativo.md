# 🎓 Pilar Educativo
#GDD #CosmosRunner #educacao

← [[01 - Visão Geral]]

## Matéria
Ciências

## Tema
Sistema Solar — características dos planetas

## Conteúdo Ensinado por Planeta
| Planeta    | O que o jogador aprende jogando                        |
|------------|--------------------------------------------------------|
| Mercúrio   | Sem atmosfera = sem proteção, calor extremo            |
| Vênus      | Atmosfera densa e tóxica, temperatura altíssima        |
| Terra      | Condições ideais para vida, referência do jogo         |
| Marte      | Gravidade menor, tempestades de areia                  |
| Júpiter    | Gravidade enorme, ventos fortíssimos                   |
| Saturno    | Anéis de gelo como plataformas instáveis               |
| Urano      | Rotação inclinada, fases invertidas                    |
| Netuno     | Ventos mais rápidos do sistema solar, visibilidade zero|

## Objetivo de Aprendizagem
O jogador, ao completar o jogo, consegue associar cada planeta com suas características físicas principais — sem ter estudado formalmente.

## Como a Matéria Aparece
- **Não há perguntas ou provas**
- As propriedades dos planetas viram mecânicas de gameplay
- Exemplo: em Marte a gravidade do pulo é maior → o jogador sente que é mais leve
- Exemplo: em Júpiter o personagem anda mais devagar → a gravidade é esmagadora

---
← [[01 - Visão Geral]] | → [[03 - Narrativa]]
