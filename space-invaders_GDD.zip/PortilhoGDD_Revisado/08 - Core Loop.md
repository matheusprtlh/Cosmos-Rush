# Core Loop

```text
1. Andar e pular entre plataformas
2. Evitar obstáculos
3. Administrar oxigênio
4. Coletar cápsulas
5. Encontrar Núcleo de Dados
6. Abrir portal
7. Finalizar fase
```

## Ação Principal do Jogador
O jogador passará a maior parte do tempo:
- pulando;
- administrando oxigênio;
- atravessando obstáculos;
- adaptando movimentação à gravidade.