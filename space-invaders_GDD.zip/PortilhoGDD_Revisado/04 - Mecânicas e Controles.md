# Mecânicas e Controles

## Movimento
- A = mover para esquerda
- D = mover para direita
- Espaço = pular

## Sistema de Gravidade

### Marte
gravidade_global = 0.6

Efeitos:
- salto 40% maior
- queda mais lenta

## Sistema de Oxigênio

Oxigênio diminui continuamente.

### Regras
- Oxigênio inicial = 100
- Perda contínua = 1 por segundo
- Cápsulas recuperam 20

## Condições de Derrota
- Oxigênio <= 0
- Cair fora do mapa

## Pseudocódigo — Gravidade

```text
AO iniciar fase:
    gravidade_global = 0.6

SE jogador pular:
    aplicar_forca_pulo(12)
```

## Pseudocódigo — Oxigênio

```text
A cada 1 segundo:
    oxigenio -= 1

SE oxigenio <= 0:
    game_over()
```