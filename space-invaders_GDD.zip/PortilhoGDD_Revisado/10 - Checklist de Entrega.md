# Checklist MVP

## Necessário para o primeiro protótipo
- [ ] Movimento do personagem
- [ ] Sistema de pulo
- [ ] Gravidade reduzida
- [ ] Barra de oxigênio
- [ ] Cápsulas coletáveis
- [ ] Núcleo da fase
- [ ] Portal funcional
- [ ] Tela de derrota

## Itens removidos temporariamente
- [ ] História completa
- [ ] Sistema de múltiplos planetas
- [ ] Menus avançados
- [ ] Meteoros
- [ ] Loja
- [ ] Diferentes inimigos