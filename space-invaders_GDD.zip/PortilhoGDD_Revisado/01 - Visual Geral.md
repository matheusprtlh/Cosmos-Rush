# Cosmos Runner

## Elevator Pitch
Cosmos Runner é um jogo de plataforma 2D focado em adaptação física. O jogador controla o astronauta ORBIT e precisa atravessar fases onde a gravidade e os obstáculos ambientais mudam conforme as características de cada planeta.

## Objetivo Principal
Coletar o Núcleo de Dados da fase e alcançar o portal de saída antes que o oxigênio acabe.