# Fases e Planetas

## MVP Atual

O primeiro protótipo terá apenas:
- 1 planeta
- 1 fase
- obstáculos simples
- sistema de oxigênio
- gravidade variável

## Planeta Inicial — Marte

Características:
- gravidade reduzida
- plataformas simples
- cápsulas de oxigênio
- núcleo coletável
- portal final

## Condição de Vitória

```text
SE jogador coletar núcleo:
    liberar portal

SE jogador entrar no portal:
    finalizar fase
```