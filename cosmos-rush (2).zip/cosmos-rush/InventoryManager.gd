extends Node

# Dicionário que guarda os itens e suas quantidades
var inventario: Dictionary = {}

func adicionar(item: String, quantidade: int = 1):
	if inventario.has(item):
		inventario[item] += quantidade
	else:
		inventario[item] = quantidade
	print("[Inventário] +", quantidade, " ", item)

func remover(item: String, quantidade: int = 1) -> bool:
	if inventario.has(item) and inventario[item] >= quantidade:
		inventario[item] -= quantidade
		if inventario[item] <= 0:
			inventario.erase(item)
		return true
	return false

func tem(item: String, quantidade: int = 1) -> bool:
	return inventario.get(item, 0) >= quantidade

func get_quantidade(item: String) -> int:
	return inventario.get(item, 0)

func resetar():
	inventario.clear()
