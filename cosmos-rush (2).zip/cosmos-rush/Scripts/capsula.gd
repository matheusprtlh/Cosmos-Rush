extends Area2D

# Sinal para avisar que foi coletada (opcional, mas bom para efeitos)
signal capsula_coletada

func _ready():
	# Conecta o sinal de entrada de corpo
	body_entered.connect(_on_body_entered)

func _on_body_entered(body):
	# Verifica se quem entrou é o Player
	if body.name == "Player" or body.is_in_group("player"):
		# Chama a função de recuperação no player
		if body.has_method("recuperar_oxigenio"):
			body.recuperar_oxigenio()
		
		# Emite sinal (se quiser adicionar partículas depois)
		emit_signal("capsula_coletada")
		
		# Destroi a cápsula
		queue_free()
